from langchain_community.document_loaders import UnstructuredHTMLLoader
from langchain.document_loaders import DirectoryLoader, CSVLoader, UnstructuredWordDocumentLoader, PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.retrievers import ParentDocumentRetriever
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.storage import LocalFileStore
from langchain.storage._lc_store import create_kv_docstore
import os

#%%
data_directory="C:/research/RAG/data_sets/wiki/zh/articles"
persist_directory = "C:/research/RAG/vectorstore/chroma"
doc_store_dir = 'C:/research/RAG/store_location'

llm_model ="llama3.2"
embedding_model='sentence-transformers/all-MiniLM-L6-v2'
embeddings = HuggingFaceEmbeddings(model_name=embedding_model)

fs = LocalFileStore(doc_store_dir)
store_kv = create_kv_docstore(fs)

child_chunk_size, child_chunk_overlap, parent_chunk_size, parent_chunk_overlap = 400, 50, 1200, 300

#%%
def load_docs(directory):
    # Load the documents
    loaders = [
        DirectoryLoader(directory, glob="**/*.pdf", loader_cls=PyPDFLoader, recursive=True, show_progress=True, use_multithreading=True),
        DirectoryLoader(directory, glob="**/*.html", loader_cls=UnstructuredHTMLLoader, recursive=True, show_progress=True, use_multithreading=True)
    ]


    documents=[]
    for loader in loaders:
        data =loader.load()
        documents.extend(data)

    return documents

def create_vectordb(persist_directory, embeddings):
    vector_db_chroma = Chroma(
        persist_directory=persist_directory,
        embedding_function=embeddings,
    )
    return vector_db_chroma

def create_document_retriever(vector_db, store, child_chunk_size, child_chunk_overlap, parent_chunk_size, parent_chunk_overlap):
    child_splitter = RecursiveCharacterTextSplitter(chunk_size=child_chunk_size, chunk_overlap=child_chunk_overlap)
    parent_splitter = RecursiveCharacterTextSplitter(chunk_size=parent_chunk_size, chunk_overlap=parent_chunk_overlap)
    parent_document_retriever = ParentDocumentRetriever(
      vectorstore=vector_db,
      docstore=store,
      child_splitter=child_splitter,
      parent_splitter=parent_splitter
    )
    return parent_document_retriever
#%%
vector_db_chroma = create_vectordb(persist_directory, embeddings)
parent_document_retriever = create_document_retriever(vector_db_chroma, store_kv, child_chunk_size, child_chunk_overlap, parent_chunk_size, parent_chunk_overlap)

dir_list=os.listdir(data_directory)

tot_count = len(dir_list)
proc_count=1
for direct in dir_list:
    print(f'{proc_count} out of {tot_count} processing: {direct}')
    if direct.isalnum() or (ord(direct) >= 0x4E00 and ord(direct) <= 0x9FFF):
        iter_direct = os.path.join(data_directory, direct)
        documents = load_docs(iter_direct)
        parent_document_retriever.add_documents(documents, ids=None)
    
    proc_count += 1
vector_db_chroma.persist()
    