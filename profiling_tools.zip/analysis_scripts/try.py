import re
import pandas as pd
import matplotlib.pyplot as plt

# perf_data['Time'] = (perf_data['DateTime']-perf_data['DateTime'].min()).dt.total_seconds()
# perf_data['DateTime'] = pd.to_datetime(perf_data['Time of Day'], format='%m/%d/%Y %H:%M:%S.%f')

def proc_mon_convert_time(x):
    h, m, s, AP = re.split(':|\s', x)
    if AP == 'PM':
        h = int(h) + 12
    return int(h)*3600 + int(m)*60 + float(s)

def proc_mon_convert_detail(x):
    _, _, offset,_,_,size,*_= re.split(':|\s', x)
    return size



#%%
proc_data=pd.read_csv('C:/research/procmon_results/procmon_llama_load.CSV')
proc_data['Time'] = pd.to_datetime(proc_data['Time of Day'], format='%H:%M:%S.%f %p').dt.time
proc_data['Detail'] = proc_data['Detail'].str.replace(',','')
proc_data['size'] = proc_data['Detail'].apply(proc_mon_convert_detail)

proc_data['size'] = proc_data['size'].astype(float)
proc_data['size kB'] = proc_data['size']/1024

proc_data_read = proc_data[proc_data['Operation']=='ReadFile']
proc_data_write = proc_data[proc_data['Operation']=='WriteFile']

ax_read = proc_data_read.plot(x="Time", y=["size kB"], label=['File Read'], 
               title='Host File Read', grid=True, style='.',
               xlabel='Time', ylabel='kB')
ax_write = proc_data_write.plot(x="Time", y=["size kB"], label=['File Write'],
               title='Host File Write', grid=True, style='.',
               xlabel='Time', ylabel='kB')
#%%
perf_data=pd.read_csv('C:/research/procmon_results/perf_count_res_llama_load.CSV', skiprows=[1])
perf_data.rename(columns={'(PDH-CSV 4.0) (Pacific Daylight Time)(420)': 'Time of Day'}, inplace=True)
new_col = []
for col in perf_data.columns:
    name = re.split(r'[\\|(|)]', col)
    if name[-1] == 'Temperature' or name[-1] == 'Power':
        new_col.append(name[-3]+'_'+name[-1])
    else:
        new_col.append(name[-1])
perf_data.columns = new_col

perf_data['Time'] = pd.to_datetime(perf_data['Time of Day'], format='%m/%d/%Y %H:%M:%S.%f').dt.time

ignore = ['Time', 'Time of Day']
perf_data = (perf_data.set_index(ignore, append=True)
        .astype(float)
        .reset_index(ignore)
       )
perf_data['MBytes Sent/sec'] = perf_data['Bytes Sent/sec']/1024**2
perf_data['MBytes Received/sec'] = perf_data['Bytes Received/sec']/1024**2
perf_data['Disk Read MBytes/sec'] = perf_data['Disk Read Bytes/sec']/1024**2
perf_data['Disk Write MBytes/sec'] = perf_data['Disk Write Bytes/sec']/1024**2

perf_data.plot(x="Time", y=["Disk Read MBytes/sec", "Disk Write MBytes/sec"], label=['Read BW', 'Write BW'],
               title='Disk BW', grid=True,
               xlabel='Time', ylabel='MB/s')
perf_data.plot(x="Time", y=["Disk Reads/sec", "Disk Writes/sec"], label=['Read IOps', 'Write IOps'],
               title='Disk IOps', grid=True,
               xlabel='Time', ylabel='IO/s')
perf_data.plot(x="Time", y=['% Processor Time','% Disk Read Time', '% Disk Write Time'], label=['CPU', 'SSD Read', 'SSD Write'],
               title='CPU and Disk Active Percentage', grid=True,
               xlabel='Time', ylabel='Active Percentage (%)')
perf_data.plot(x="Time", y=['Available MBytes'], legend=False,
               title='DRAM Availability', grid=True,
               xlabel='Time', ylabel='MBytes')

perf_data.plot(x="Time", y=['MBytes Sent/sec', 'MBytes Received/sec'], label=['Sent', 'Received'],
               title='Network Activity', grid=True,
               xlabel='Time', ylabel='BW (MB/s)')

perf_data.plot(x="Time", y=['_SB.TZ0_Temperature', '_SB.TZ01_Temperature', '_SB.TZ02_Temperature',
'_SB.TZ03_Temperature'], 
               title='Temperature Sensors', label=['Zone 0', 'Zone 1', 'Zone 2', 'Zone 3'],
               grid=True,
               xlabel='Time', ylabel='k')
perf_data.plot(x="Time", y=['CPU_CLUSTER_0_Power', 'CPU_CLUSTER_1_Power','CPU_CLUSTER_2_Power', 'GPU_Power', 'SYS_Power', 'SYS_1A_Power',
'SYS_1B_Power'], 
               title='Power', grid=True,
               xlabel='Time', ylabel='mW')

perf_data.plot(x="Time", y=['Pages Input/sec', 'Pages Output/sec'], label=['Swap In', 'Swap Out'],
               title='Page Swaps', grid=True,
               xlabel='Time', ylabel='Pages')

perf_data.plot(x="Time", y=['Avg. Disk Queue Length',
'Avg. Disk Read Queue Length', 'Avg. Disk Write Queue Length',], label=['Avg Tot QD', 'Avg Read QD', 'Avg Write QD'],
               title='Average Disk QD', grid=True,
               xlabel='Time', ylabel='QD')
#%%
col_names=['idx', 'Time of Day', 'Duration', 'Disk', 'Op', 'LBA Start', 'Size']
trace_data=pd.read_csv('C:/research/procmon_results/llama_load_trace.LOG', sep='\t', names=col_names, index_col=False)
trace_data['Time'] = pd.to_datetime(trace_data['Time of Day'], format='%H:%M:%S.%f %p').dt.time
trace_data['Size kB'] = trace_data['Size']*512/1024
trace_data_read = trace_data[trace_data['Op']=='Read']
trace_data_write = trace_data[trace_data['Op']=='Write']

trace_data_read.plot(x="Time", y=['Size kB'], label=['Disk Read'],
               title='Llama 3.1 Loading Read Size', grid=True, style='.', ax=ax_read,
               xlabel='Time', ylabel='kB')
trace_data_write.plot(x="Time", y=['Size kB'], label=['Disk Write'],
               title='Llama 3.1 Loading Write Size', grid=True, style='.', ax=ax_write,
               xlabel='Time', ylabel='kB')

trace_data_read.plot(x="Time", y=['LBA Start'], legend=False,
               title='Llama 3.1 Disk Read LBAs', grid=True, style='.',
               xlabel='Time', ylabel='LBA')
trace_data_write.plot(x="Time", y=['LBA Start'], legend=False,
               title='Llama 3.1 Disk Write LBAs', grid=True, style='.',
               xlabel='Time', ylabel='LBA')

#%% boot
proc_data=pd.read_csv('C:/research/procmon_results/bootlog1.CSV')
proc_data['Time'] = pd.to_datetime(proc_data['Time of Day'], format='%H:%M:%S.%f %p').dt.time
proc_data['Detail'] = proc_data['Detail'].str.replace(',','')
proc_data['size'] = proc_data['Detail'].apply(proc_mon_convert_detail)

proc_data['size'] = proc_data['size'].astype(float)
proc_data['size kB'] = proc_data['size']/1024

proc_data_read = proc_data[proc_data['Operation']=='ReadFile']
proc_data_write = proc_data[proc_data['Operation']=='WriteFile']

ax_read = proc_data_read.plot(x="Time", y=["size kB"], label=['File Read'], 
               title='Host File Read', grid=True, style='.',
               xlabel='Time', ylabel='kB')
ax_write = proc_data_write.plot(x="Time", y=["size kB"], label=['File Write'],
               title='Host File Write', grid=True, style='.',
               xlabel='Time', ylabel='kB')